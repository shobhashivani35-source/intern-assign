<div class="footer">
    Smart Health Prediction System <br>
    © Reserved by Ankita Kumari
</div>

</body>
</html>
