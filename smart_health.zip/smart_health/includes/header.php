<!DOCTYPE html>
<html>
<head>
<title>Smart Health</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">Smart Health</div>
    <div class="menu">
        <a href="http://localhost/smart_health/index.php">Home</a>
        <a href="http://localhost/smart_health/user/register.php">Register</a>
        <a href="http://localhost/smart_health/user/login.php">Login</a>
        <a href="http://localhost/smart_health/admin/add_doctor.php">doctor</a>
    
        <a href="http://localhost/smart_health/contact.php">Contact</a>
    </div>
</div>
