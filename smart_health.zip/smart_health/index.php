<?php include "includes/header.php"; ?>

<!-- HERO SECTION -->
<div class="hero">
    <div class="hero-left">
        <h1>Smart Health Prediction System</h1>
        <p>Select symptoms and get instant health guidance.</p>
        <a href="user/register.php" class="btn">Get Started</a>
    </div>

    <div class="hero-right">
        <img src="https://thumbs.dreamstime.com/b/digital-healthcare-technology-icon-vector-illustration-design-digital-healthcare-technology-icon-109166917.jpg" alt="Health Icon">
    </div>
</div>

<!-- HOW IT WORKS -->
<h2 class="center">How It Works</h2>

<div class="steps">
    <div class="step-box">
        <h4>Step 1</h4>
        <p>Register & Login</p>
    </div>

    <div class="step-box">
        <h4>Step 2</h4>
        <p>Select Symptoms</p>
    </div>

    <div class="step-box">
        <h4>Step 3</h4>
        <p>View Result</p>
    </div>
</div>

<?php include "includes/footer.php"; ?>
